"""Typer-based CLI for NetConverge Assistant."""
from __future__ import annotations
import json
import time
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from netconverge.domain.models.intents import (
    VoiceAccessPort, QoSPolicy, QoSClass, ACL, ACLRule, DSCP,
)
from netconverge.domain.models.telemetry import quality_band
from netconverge.application.analysis.rtp_quality import RTPStreamAnalyzer
from netconverge.infrastructure.vendors.cisco_ios import CiscoIOS
from netconverge.infrastructure.vendors.huawei_vrp import HuaweiVRP
from netconverge.infrastructure.capture.synthetic import synth_g711_stream

app = typer.Typer(help="NetConverge Assistant — multi-vendor config + RTP analysis")
config_app = typer.Typer(help="Generate vendor-specific configuration")
analyze_app = typer.Typer(help="Analyze RTP streams")
app.add_typer(config_app, name="config")
app.add_typer(analyze_app, name="analyze")
console = Console()

VENDORS = {"cisco_ios": CiscoIOS, "huawei_vrp": HuaweiVRP}


def _resolve(vendor: str):
    if vendor not in VENDORS:
        raise typer.BadParameter(f"vendor must be one of {list(VENDORS)}")
    return VENDORS[vendor]()


@config_app.command("voice-port")
def voice_port(
    vendor: str = typer.Option(..., help="cisco_ios | huawei_vrp"),
    interface: str = typer.Option(...),
    data_vlan: int = typer.Option(...),
    voice_vlan: int = typer.Option(...),
    description: str = typer.Option(""),
    trust: str = typer.Option("cos", help="cos | dscp"),
):
    intent = VoiceAccessPort(
        interface=interface, description=description,
        data_vlan=data_vlan, voice_vlan=voice_vlan, trust_mode=trust,
    )
    cfg = _resolve(vendor).render_voice_port(intent)
    console.print(Panel(cfg, title=f"[{vendor}] voice access port",
                        border_style="cyan"))


@config_app.command("acl-voice")
def acl_voice(
    vendor: str = typer.Option(...),
    name: str = typer.Option("VOICE-PERMIT"),
):
    """Pre-built ACL allowing SIP signaling (5060) + RTP voice range."""
    acl = ACL(name=name, type="extended", rules=[
        ACLRule(action="permit", protocol="udp", dst_port=5060, remark="SIP UDP"),
        ACLRule(action="permit", protocol="tcp", dst_port=5060, remark="SIP TCP"),
        ACLRule(action="permit", protocol="udp",
                dst_port_range=(16384, 32767), remark="RTP audio"),
        ACLRule(action="deny", protocol="ip"),
    ])
    cfg = _resolve(vendor).render_acl(acl)
    console.print(Panel(cfg, title=f"[{vendor}] {name}", border_style="cyan"))


@config_app.command("qos-voice-video")
def qos_voice_video(
    vendor: str = typer.Option(...),
    interface: str = typer.Option(...),
    name: str = typer.Option("WAN-EGRESS"),
):
    """Pre-built QoS policy: voice=PQ 30%, video=AF 30%, signaling=AF 5%."""
    policy = QoSPolicy(name=name, apply_to_interface=interface, classes=[
        QoSClass(name="VOICE-RTP", match_dscp=DSCP.EF,   priority=True,
                 bandwidth_percent=30),
        QoSClass(name="VIDEO-RTP", match_dscp=DSCP.AF41, bandwidth_percent=30),
        QoSClass(name="VOICE-SIG", match_dscp=DSCP.CS3,  bandwidth_percent=5),
    ])
    cfg = _resolve(vendor).render_qos_policy(policy)
    console.print(Panel(cfg, title=f"[{vendor}] {name}", border_style="cyan"))


@analyze_app.command("synth")
def analyze_synth(
    packets: int = typer.Option(1000),
    loss: float = typer.Option(0.0, help="loss rate 0..1"),
    jitter_ms: float = typer.Option(0.0, help="injected gaussian jitter (ms)"),
    owd_ms: float = typer.Option(50.0, help="base one-way delay (ms)"),
):
    a = RTPStreamAnalyzer(ssrc=0xCAFE, assumed_owd_ms=owd_ms)
    for pkt in synth_g711_stream(
            packets=packets, loss_rate=loss, jitter_ms=jitter_ms, seed=42):
        a.ingest(pkt)
    m = a.snapshot(payload_type=0)
    table = Table(title=f"SSRC 0x{a.ssrc:X} — codec {m.codec}",
                  show_header=False, border_style="cyan")
    table.add_column("k"); table.add_column("v")
    table.add_row("packets", f"{m.packets_received}/{m.packets_expected}")
    table.add_row("loss",    f"{m.loss_rate*100:.2f} %")
    table.add_row("jitter",  f"{m.jitter_ms:.2f} ms")
    table.add_row("delay",   f"{m.one_way_delay_ms:.1f} ms")
    table.add_row("R-factor", f"{m.r_factor}")
    table.add_row("MOS",      f"{m.mos}  ({quality_band(m.mos)})")
    console.print(table)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
