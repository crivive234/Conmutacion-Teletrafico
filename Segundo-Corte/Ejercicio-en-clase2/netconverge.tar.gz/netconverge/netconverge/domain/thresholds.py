"""
Network quality thresholds from public standards.

References:
  - ITU-T G.114 (one-way transmission time)
  - RFC 4594 (DiffServ Service Classes)
  - ITU-T P.800 / G.107 (MOS bands)
"""

# Voice (one-way) — ITU-T G.114
VOICE_DELAY_GOOD_MS = 150
VOICE_DELAY_MAX_MS = 400
VOICE_JITTER_MAX_MS = 30
VOICE_LOSS_MAX_RATIO = 0.01  # 1%

# Video conferencing — informal industry consensus aligned with RFC 4594
VIDEO_DELAY_GOOD_MS = 150
VIDEO_JITTER_MAX_MS = 50
VIDEO_LOSS_MAX_RATIO = 0.001  # 0.1%

# MOS bands (ITU-T P.800 quality scale)
MOS_EXCELLENT = 4.0
MOS_GOOD = 3.6
MOS_ACCEPTABLE = 3.1
MOS_POOR = 2.6
