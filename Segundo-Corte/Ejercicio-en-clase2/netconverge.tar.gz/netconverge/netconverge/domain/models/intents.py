"""
Network intent models — vendor-agnostic, validated with Pydantic v2.

These describe WHAT the user wants (a voice access port, a QoS policy,
an ACL), not WHICH commands to execute. The vendor adapters translate
intent → vendor-specific configuration.
"""
from __future__ import annotations
from enum import Enum
from typing import Literal, Optional, Tuple
from pydantic import BaseModel, Field, field_validator, IPvAnyNetwork, ConfigDict


# DSCP values per RFC 4594 (Diffserv recommendations).
class DSCP(str, Enum):
    EF = "ef"        # 46 — Expedited Forwarding (voz RTP)
    AF41 = "af41"    # 34 — Assured Forwarding (video conferencia)
    AF31 = "af31"    # 26 — video streaming
    CS3 = "cs3"      # 24 — señalización (SIP, H.323)
    CS6 = "cs6"      # 48 — control de red
    DEFAULT = "default"  # 0 — best effort


DSCP_VALUE: dict[str, int] = {
    DSCP.EF.value: 46,
    DSCP.AF41.value: 34,
    DSCP.AF31.value: 26,
    DSCP.CS3.value: 24,
    DSCP.CS6.value: 48,
    DSCP.DEFAULT.value: 0,
}


class VoiceAccessPort(BaseModel):
    """Puerto de acceso con teléfono IP + PC en daisy-chain."""
    model_config = ConfigDict(use_enum_values=True)

    interface: str = Field(..., description="Cisco: GigabitEthernet0/1; Huawei: GigabitEthernet0/0/1")
    description: str = ""
    data_vlan: int = Field(..., ge=1, le=4094)
    voice_vlan: int = Field(..., ge=1, le=4094)
    trust_mode: Literal["cos", "dscp"] = "cos"
    portfast: bool = True

    @field_validator("voice_vlan")
    @classmethod
    def _voice_distinct(cls, v: int, info) -> int:
        if info.data.get("data_vlan") == v:
            raise ValueError("voice_vlan must differ from data_vlan")
        return v


class QoSClass(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    name: str = Field(..., min_length=1, max_length=32)
    match_dscp: DSCP
    priority: bool = False
    bandwidth_percent: Optional[int] = Field(default=None, ge=1, le=99)


class QoSPolicy(BaseModel):
    name: str = Field(..., min_length=1, max_length=32)
    classes: list[QoSClass]
    apply_to_interface: str
    direction: Literal["input", "output"] = "output"

    @field_validator("classes")
    @classmethod
    def _budget_le_100(cls, v: list[QoSClass]) -> list[QoSClass]:
        total = sum((c.bandwidth_percent or 0) for c in v)
        if total > 99:
            raise ValueError(f"sum of bandwidth_percent={total} exceeds 99 (need headroom for default)")
        return v


class ACLRule(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    action: Literal["permit", "deny"]
    protocol: Literal["ip", "tcp", "udp", "icmp"]
    src: IPvAnyNetwork | Literal["any"] = "any"
    dst: IPvAnyNetwork | Literal["any"] = "any"
    dst_port: Optional[int] = Field(default=None, ge=1, le=65535)
    dst_port_range: Optional[Tuple[int, int]] = None
    remark: Optional[str] = None

    @field_validator("dst_port_range")
    @classmethod
    def _range_ordered(cls, v):
        if v is not None and v[0] >= v[1]:
            raise ValueError("dst_port_range must satisfy low < high")
        return v


class ACL(BaseModel):
    name: str = Field(..., min_length=1, max_length=32)
    type: Literal["standard", "extended"] = "extended"
    rules: list[ACLRule]
