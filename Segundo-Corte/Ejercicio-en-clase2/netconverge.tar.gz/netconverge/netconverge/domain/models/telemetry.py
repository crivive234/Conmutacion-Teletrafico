"""Telemetry domain models — used by the analyzer and the WebSocket layer."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal


@dataclass
class StreamMetrics:
    """Snapshot of one RTP stream's quality at a point in time."""
    ssrc: int = 0
    codec: str = ""
    packets_received: int = 0
    packets_lost: int = 0
    packets_expected: int = 0
    jitter_ms: float = 0.0
    one_way_delay_ms: float = 0.0
    loss_rate: float = 0.0
    mos: float = 0.0
    r_factor: float = 0.0

    # internal RFC 3550 / sequence tracking state
    _last_seq: int | None = field(default=None, repr=False)
    _last_arrival: float | None = field(default=None, repr=False)
    _last_ts: int | None = field(default=None, repr=False)
    _jitter_units: float = field(default=0.0, repr=False)


@dataclass
class TelemetryEvent:
    timestamp: datetime
    severity: Literal["info", "warning", "critical"]
    source: str        # "analyzer", "config", "system"
    message: str
    ssrc: int | None = None


def quality_band(mos: float) -> str:
    """Translate MOS to ITU-T-aligned quality band."""
    if mos >= 4.0:
        return "EXCELLENT"
    if mos >= 3.6:
        return "GOOD"
    if mos >= 3.1:
        return "ACCEPTABLE"
    if mos >= 2.6:
        return "POOR"
    return "UNACCEPTABLE"
