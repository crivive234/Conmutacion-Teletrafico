"""Synthetic RTP traffic generator for demos and tests (no network needed)."""
from __future__ import annotations
import random
import time
from typing import Iterator

from netconverge.application.analysis.rtp_quality import RTPPacket


def synth_g711_stream(
    packets: int = 1000,
    loss_rate: float = 0.0,
    jitter_ms: float = 0.0,
    ptime_ms: int = 20,
    payload_type: int = 0,
    seed: int | None = None,
    base_arrival: float | None = None,
) -> Iterator[RTPPacket]:
    """
    Yield RTPPacket objects modelling a G.711 (8 kHz, 20 ms ptime) stream
    with controllable loss and Gaussian network jitter.

    G.711 @ 20 ms produces 160 samples per packet.
    """
    rng = random.Random(seed)
    seq = rng.randint(0, 0xFFFF)
    ts = 0
    base = base_arrival if base_arrival is not None else time.time()
    samples_per_pkt = (ptime_ms * 8000) // 1000
    interval_s = ptime_ms / 1000.0

    for i in range(packets):
        seq = (seq + 1) & 0xFFFF
        ts += samples_per_pkt
        if rng.random() < loss_rate:
            continue  # packet "lost" in network
        wobble = rng.gauss(0, jitter_ms) / 1000.0
        arrival = base + i * interval_s + wobble
        yield RTPPacket(
            seq=seq, timestamp=ts, arrival_s=arrival,
            payload_type=payload_type, clock_rate=8000,
        )
