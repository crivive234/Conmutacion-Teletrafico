"""FastAPI application — REST endpoints + WebSocket telemetry stream."""
from __future__ import annotations
import asyncio
import json
import random
import time
from contextlib import asynccontextmanager
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from netconverge.domain.models.intents import (
    VoiceAccessPort, QoSPolicy, ACL,
)
from netconverge.domain.models.telemetry import quality_band
from netconverge.application.analysis.rtp_quality import RTPStreamAnalyzer
from netconverge.infrastructure.vendors.cisco_ios import CiscoIOS
from netconverge.infrastructure.vendors.huawei_vrp import HuaweiVRP
from netconverge.infrastructure.capture.synthetic import synth_g711_stream

VENDORS = {"cisco_ios": CiscoIOS(), "huawei_vrp": HuaweiVRP()}


# ----------------------------------------------------------------- API models
class RenderRequest(BaseModel):
    vendor: str
    intent_type: str   # "voice_port" | "qos_policy" | "acl"
    intent_data: dict[str, Any]


class RenderResponse(BaseModel):
    vendor: str
    intent_type: str
    config: str


# ---------------------------------------------------------------- WebSocket hub
class TelemetryHub:
    """Broadcasts metrics snapshots to all connected WebSocket clients."""

    def __init__(self) -> None:
        self.clients: set[WebSocket] = set()
        self.task: asyncio.Task | None = None

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self.clients.add(ws)

    def disconnect(self, ws: WebSocket) -> None:
        self.clients.discard(ws)

    async def broadcast(self, payload: dict) -> None:
        dead = []
        for ws in self.clients:
            try:
                await ws.send_text(json.dumps(payload))
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


HUB = TelemetryHub()


# ----------------------------- background telemetry simulation -----------------
async def telemetry_loop() -> None:
    """
    Continuously feed synthetic RTP packets through several analyzers
    and broadcast snapshots once per second.
    """
    streams = {
        0xCAFE0001: RTPStreamAnalyzer(0xCAFE0001, assumed_owd_ms=80),
        0xCAFE0002: RTPStreamAnalyzer(0xCAFE0002, assumed_owd_ms=120),
        0xCAFE0003: RTPStreamAnalyzer(0xCAFE0003, assumed_owd_ms=200),
    }

    # Distinct profiles so the dashboard shows variety
    profiles = {
        0xCAFE0001: dict(loss_rate=0.001, jitter_ms=2.5),   # healthy
        0xCAFE0002: dict(loss_rate=0.02,  jitter_ms=12.0),  # degrading
        0xCAFE0003: dict(loss_rate=0.07,  jitter_ms=30.0),  # bad
    }

    iters = {
        ssrc: iter(synth_g711_stream(
            packets=10**9, loss_rate=p["loss_rate"], jitter_ms=p["jitter_ms"],
            seed=ssrc,
        ))
        for ssrc, p in profiles.items()
    }

    while True:
        # Feed ~50 packets into each stream per tick (1 s, 20 ms ptime)
        for ssrc, analyzer in streams.items():
            for _ in range(50):
                try:
                    pkt = next(iters[ssrc])
                except StopIteration:
                    break
                analyzer.ingest(pkt)
        snapshots = []
        events = []
        for ssrc, analyzer in streams.items():
            snap = analyzer.snapshot(payload_type=0)
            data = {k: v for k, v in asdict(snap).items() if not k.startswith("_")}
            data["ssrc_hex"] = f"0x{ssrc:08X}"
            data["band"] = quality_band(snap.mos)
            snapshots.append(data)
            # synthesize an alert event when MOS dips
            if snap.mos < 3.6 and random.random() < 0.15:
                events.append({
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "severity": "warning" if snap.mos > 3.0 else "critical",
                    "source": "analyzer",
                    "ssrc_hex": f"0x{ssrc:08X}",
                    "message": f"MOS={snap.mos} ({quality_band(snap.mos)}) "
                               f"jitter={snap.jitter_ms:.1f}ms loss={snap.loss_rate*100:.1f}%",
                })
        await HUB.broadcast({
            "type": "telemetry",
            "ts": time.time(),
            "streams": snapshots,
            "events": events,
        })
        await asyncio.sleep(1.0)


# ----------------------------------------------------------------- FastAPI app
@asynccontextmanager
async def lifespan(app: FastAPI):
    HUB.task = asyncio.create_task(telemetry_loop())
    try:
        yield
    finally:
        if HUB.task:
            HUB.task.cancel()


app = FastAPI(
    title="NetConverge Assistant API",
    version="0.1.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "netconverge"}


@app.get("/api/v1/vendors")
def vendors() -> dict[str, list[str]]:
    return {"vendors": list(VENDORS.keys())}


@app.post("/api/v1/config/render", response_model=RenderResponse)
def render_config(req: RenderRequest) -> RenderResponse:
    if req.vendor not in VENDORS:
        raise HTTPException(404, f"Unknown vendor '{req.vendor}'")
    adapter = VENDORS[req.vendor]
    try:
        if req.intent_type == "voice_port":
            cfg = adapter.render_voice_port(VoiceAccessPort(**req.intent_data))
        elif req.intent_type == "qos_policy":
            cfg = adapter.render_qos_policy(QoSPolicy(**req.intent_data))
        elif req.intent_type == "acl":
            cfg = adapter.render_acl(ACL(**req.intent_data))
        else:
            raise HTTPException(400, f"Unknown intent_type '{req.intent_type}'")
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return RenderResponse(vendor=req.vendor, intent_type=req.intent_type, config=cfg)


@app.websocket("/ws/telemetry")
async def telemetry_ws(ws: WebSocket) -> None:
    await HUB.connect(ws)
    try:
        while True:
            await ws.receive_text()  # keep connection alive
    except WebSocketDisconnect:
        HUB.disconnect(ws)
