"""
RTP stream quality analyzer.

References:
  - RFC 3550 (RTP) — jitter calculation §6.4.1
  - ITU-T G.107 (06/2015) — The E-model for transmission planning
  - ITU-T G.114 — one-way transmission time
  - RFC 4594 — DiffServ service classes
"""
from __future__ import annotations
from dataclasses import dataclass
from netconverge.domain.models.telemetry import StreamMetrics


# Codec impairment params (G.107 Appendix I).
# RTP payload type → (codec name, Ie_base, Bpl).
#   Ie  — equipment impairment factor at 0% loss
#   Bpl — packet-loss robustness factor (PLC effectiveness)
CODEC_PARAMS: dict[int, tuple[str, float, float]] = {
    0:  ("PCMU/G.711", 0.0, 25.1),
    8:  ("PCMA/G.711", 0.0, 25.1),
    18: ("G.729A",    11.0, 19.0),
}


@dataclass
class RTPPacket:
    seq: int             # 16-bit RTP sequence number
    timestamp: int       # RTP timestamp (codec sample units)
    arrival_s: float     # local wall-clock at capture (seconds, monotonic acceptable)
    payload_type: int
    clock_rate: int = 8000   # 8 kHz for G.711 / G.729


class RTPStreamAnalyzer:
    """
    Stateful per-SSRC analyzer.

    Usage:
        a = RTPStreamAnalyzer(ssrc=0xCAFE)
        for pkt in stream:
            a.ingest(pkt)
        report = a.snapshot()
    """
    SEQ_MOD = 1 << 16

    def __init__(self, ssrc: int, assumed_owd_ms: float = 50.0):
        """
        assumed_owd_ms: base one-way delay estimate (in ms). In production
        derive from RTCP Sender/Receiver Reports; here it is configurable
        so tests and demos can vary it deterministically.
        """
        self.ssrc = ssrc
        self.assumed_owd_ms = assumed_owd_ms
        self.m = StreamMetrics(ssrc=ssrc)

    # ------------------------------------------------------------------ ingest
    def ingest(self, p: RTPPacket) -> None:
        m = self.m
        m.packets_received += 1
        if not m.codec:
            m.codec = CODEC_PARAMS.get(p.payload_type, ("unknown", 0.0, 25.1))[0]

        # ----- sequence number tracking with 16-bit wrap-around -----
        if m._last_seq is not None:
            delta = (p.seq - m._last_seq) % self.SEQ_MOD
            if delta == 0:
                return  # duplicate
            if delta > 0x8000:
                # out-of-order; reorder is not loss
                return
            m.packets_expected += delta
            m.packets_lost += max(0, delta - 1)
        else:
            m.packets_expected = 1

        # ----- RFC 3550 §6.4.1 interarrival jitter -----
        if m._last_arrival is not None and m._last_ts is not None:
            arrival_units = (p.arrival_s - m._last_arrival) * p.clock_rate
            ts_diff = p.timestamp - m._last_ts
            d = abs(arrival_units - ts_diff)
            m._jitter_units += (d - m._jitter_units) / 16.0
            m.jitter_ms = (m._jitter_units / p.clock_rate) * 1000.0

        m._last_seq = p.seq
        m._last_arrival = p.arrival_s
        m._last_ts = p.timestamp

    # -------------------------------------------------------------- E-model
    @staticmethod
    def _Id(Ta_ms: float) -> float:
        """Delay impairment factor (G.107 simplified).

        Id = 0.024·Ta + 0.11·(Ta − 177.3)·H(Ta − 177.3)
        where H is the Heaviside step function (0 if arg<0, 1 otherwise).
        """
        base = 0.024 * Ta_ms
        if Ta_ms <= 177.3:
            return base
        return base + 0.11 * (Ta_ms - 177.3)

    @staticmethod
    def _Ie_eff(payload_type: int, loss_rate: float, burst_ratio: float = 1.0) -> float:
        """Effective equipment impairment with PLC (G.107 §A.3.2)."""
        _, Ie, Bpl = CODEC_PARAMS.get(payload_type, ("unknown", 0.0, 25.1))
        Ppl = loss_rate * 100.0  # to percent
        if Ppl <= 0:
            return Ie
        return Ie + (95 - Ie) * (Ppl / (Ppl / burst_ratio + Bpl))

    @staticmethod
    def _r_to_mos(R: float) -> float:
        """ITU-T G.107 §B.3 conversion."""
        if R < 0:
            return 1.0
        if R > 100:
            return 4.5
        return 1 + 0.035 * R + 7e-6 * R * (R - 60) * (100 - R)

    def compute_quality(self, payload_type: int = 0,
                        owd_ms: float | None = None) -> StreamMetrics:
        m = self.m
        if m.packets_expected > 0:
            m.loss_rate = m.packets_lost / m.packets_expected

        # Effective one-way delay = base + jitter buffer absorption (~ 2× jitter)
        Ta = (owd_ms if owd_ms is not None else self.assumed_owd_ms) + 2 * m.jitter_ms
        m.one_way_delay_ms = Ta

        Id = self._Id(Ta)
        Ie_eff = self._Ie_eff(payload_type, m.loss_rate)
        R = 93.2 - Id - Ie_eff

        m.r_factor = round(max(0.0, min(R, 100.0)), 2)
        m.mos = round(self._r_to_mos(R), 3)
        return m

    def snapshot(self, payload_type: int = 0) -> StreamMetrics:
        return self.compute_quality(payload_type=payload_type)
