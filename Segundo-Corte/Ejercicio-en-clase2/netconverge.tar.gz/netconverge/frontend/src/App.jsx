import useWebSocket from './hooks/useWebSocket'
import StatusBar from './components/StatusBar'
import StreamCard from './components/StreamCard'
import EventLog from './components/EventLog'
import ConfigGenerator from './components/ConfigGenerator'

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws/telemetry'

const STYLE = {
  page: { minHeight: '100vh', display: 'flex', flexDirection: 'column' },
  main: {
    display: 'grid',
    gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)',
    gap: 20, padding: 20, flex: 1,
  },
  col: { display: 'flex', flexDirection: 'column', gap: 16, minWidth: 0 },
  streams: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
    gap: 14,
  },
  sectionH: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    paddingBottom: 8, borderBottom: '1px solid var(--border)',
  },
  hLabel: {
    fontSize: 11, letterSpacing: '0.16em',
    color: 'var(--fg-2)', textTransform: 'uppercase', fontWeight: 600,
  },
  hMeta: { fontSize: 10, color: 'var(--fg-3)' },
  empty: {
    padding: '40px 20px', textAlign: 'center',
    color: 'var(--fg-3)', fontSize: 12,
    border: '1px dashed var(--border)',
  },
}

export default function App() {
  const { data, connected } = useWebSocket(WS_URL)

  const streams = data?.streams || []
  const events  = data?.events  || []

  return (
    <div style={STYLE.page}>
      <StatusBar connected={connected} />

      <div style={STYLE.main}>
        {/* LEFT — telemetry */}
        <div style={STYLE.col}>
          <div style={STYLE.sectionH}>
            <span style={STYLE.hLabel}>Live RTP Streams</span>
            <span style={STYLE.hMeta}>
              {streams.length} active · 1 Hz refresh · ITU-T G.107 / RFC 3550
            </span>
          </div>

          {streams.length === 0
            ? <div style={STYLE.empty}>
                Waiting for telemetry from backend…<br/>
                <span style={{ color: 'var(--fg-2)'}}>
                  Start with: <code>docker compose up</code>
                </span>
              </div>
            : <div style={STYLE.streams}>
                {streams.map(s => <StreamCard key={s.ssrc_hex} s={s} />)}
              </div>
          }

          <div style={{ marginTop: 8 }}>
            <div style={STYLE.sectionH}>
              <span style={STYLE.hLabel}>Event Log</span>
              <span style={STYLE.hMeta}>severity · source · message</span>
            </div>
            <EventLog events={events} />
          </div>
        </div>

        {/* RIGHT — config generator */}
        <div style={STYLE.col}>
          <div className="panel">
            <div className="panel-head">
              <span style={STYLE.hLabel}>Configuration · Voice Access Port</span>
            </div>
            <div className="panel-body">
              <ConfigGenerator />
            </div>
          </div>

          <div className="panel">
            <div className="panel-head">
              <span style={STYLE.hLabel}>Reference</span>
            </div>
            <div className="panel-body" style={{
              fontSize: 11, lineHeight: 1.7, color: 'var(--fg-1)' }}>
              <div className="label" style={{marginBottom:6}}>DSCP marking · RFC 4594</div>
              EF (46) — voice RTP<br/>
              AF41 (34) — video conf<br/>
              CS3 (24) — call signaling<br/>
              <div className="divider" style={{margin:'10px 0'}}/>
              <div className="label" style={{marginBottom:6}}>MOS bands · ITU-T P.800</div>
              ≥ 4.0 EXCELLENT<br/>
              ≥ 3.6 GOOD<br/>
              ≥ 3.1 ACCEPTABLE<br/>
              &lt; 3.1 POOR / UNACCEPTABLE
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
