/**
 * EventLog — appends incoming events with severity coloring.
 * Keeps last `cap` events, newest at top.
 */
import { useEffect, useState } from 'react'

const SEV = {
  info:     { color: 'var(--fg-2)',  glyph: '·' },
  warning:  { color: 'var(--amber)', glyph: '!' },
  critical: { color: 'var(--red)',   glyph: 'X' },
}

const STYLE = {
  list: {
    overflowY: 'auto',
    maxHeight: 460,
    fontSize: 11,
    fontVariantNumeric: 'tabular-nums',
  },
  row: {
    display: 'grid',
    gridTemplateColumns: '60px 18px 80px 1fr',
    columnGap: 10,
    padding: '6px 14px',
    borderBottom: '1px dashed var(--border)',
    alignItems: 'baseline',
  },
  ts:    { color: 'var(--fg-3)' },
  glyph: { fontWeight: 700, textAlign: 'center' },
  src:   { color: 'var(--fg-2)', textTransform: 'uppercase',
           letterSpacing: '0.08em', fontSize: 10 },
  msg:   { color: 'var(--fg-0)', whiteSpace: 'nowrap',
           overflow: 'hidden', textOverflow: 'ellipsis' },
  empty: { padding: 30, color: 'var(--fg-3)', textAlign: 'center', fontSize: 11 },
}

export default function EventLog({ events, cap = 200 }) {
  const [feed, setFeed] = useState([])

  useEffect(() => {
    if (!events || events.length === 0) return
    setFeed(prev => [...events.reverse(), ...prev].slice(0, cap))
  }, [events, cap])

  if (feed.length === 0) {
    return <div style={STYLE.empty}>No events yet — system nominal.</div>
  }
  return (
    <div style={STYLE.list}>
      {feed.map((e, i) => {
        const sev = SEV[e.severity] || SEV.info
        const time = e.timestamp ? e.timestamp.substring(11, 19) : ''
        return (
          <div key={i} style={STYLE.row}>
            <span style={STYLE.ts}>{time}</span>
            <span style={{ ...STYLE.glyph, color: sev.color }}>{sev.glyph}</span>
            <span style={STYLE.src}>{e.source}{e.ssrc_hex ? ` ${e.ssrc_hex}` : ''}</span>
            <span style={STYLE.msg}>{e.message}</span>
          </div>
        )
      })}
    </div>
  )
}
