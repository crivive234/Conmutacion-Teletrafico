/**
 * ConfigGenerator — issue a render request to the backend and show the
 * generated configuration in a code panel.
 */
import { useState } from 'react'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const STYLE = {
  form: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 },
  full: { gridColumn: '1 / -1' },
  out: {
    marginTop: 14, padding: 14,
    background: 'var(--bg-0)', border: '1px solid var(--border)',
    fontSize: 12, lineHeight: 1.55, whiteSpace: 'pre',
    overflow: 'auto', maxHeight: 320, color: 'var(--green)',
  },
  err: { color: 'var(--red)', fontSize: 11 },
}

export default function ConfigGenerator() {
  const [vendor, setVendor] = useState('cisco_ios')
  const [iface, setIface]   = useState('GigabitEthernet0/1')
  const [dataVlan, setDataVlan]   = useState(10)
  const [voiceVlan, setVoiceVlan] = useState(20)
  const [output, setOutput] = useState('')
  const [error, setError]   = useState('')
  const [busy, setBusy]     = useState(false)

  const submit = async () => {
    setBusy(true); setError(''); setOutput('')
    try {
      const r = await fetch(`${API_BASE}/api/v1/config/render`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendor,
          intent_type: 'voice_port',
          intent_data: {
            interface: iface,
            data_vlan:  Number(dataVlan),
            voice_vlan: Number(voiceVlan),
            description: 'Phone + PC',
          },
        }),
      })
      if (!r.ok) { setError(`HTTP ${r.status}: ${await r.text()}`); return }
      const j = await r.json()
      setOutput(j.config)
    } catch (e) { setError(String(e)) }
    finally { setBusy(false) }
  }

  return (
    <div>
      <div style={STYLE.form}>
        <div style={STYLE.full}>
          <div className="label" style={{ marginBottom: 6 }}>Vendor</div>
          <select value={vendor} onChange={e => setVendor(e.target.value)}>
            <option value="cisco_ios">Cisco IOS</option>
            <option value="huawei_vrp">Huawei VRP</option>
          </select>
        </div>

        <div style={STYLE.full}>
          <div className="label" style={{ marginBottom: 6 }}>Interface</div>
          <input value={iface} onChange={e => setIface(e.target.value)} />
        </div>

        <div>
          <div className="label" style={{ marginBottom: 6 }}>Data VLAN</div>
          <input type="number" value={dataVlan}
                 onChange={e => setDataVlan(e.target.value)} />
        </div>
        <div>
          <div className="label" style={{ marginBottom: 6 }}>Voice VLAN</div>
          <input type="number" value={voiceVlan}
                 onChange={e => setVoiceVlan(e.target.value)} />
        </div>

        <div style={{...STYLE.full, display:'flex', gap:10, marginTop: 4}}>
          <button className="primary" onClick={submit} disabled={busy}>
            {busy ? 'rendering…' : 'render config'}
          </button>
          <button onClick={() => { setOutput(''); setError('') }}>clear</button>
        </div>
      </div>

      {error && <p style={STYLE.err}>⚠ {error}</p>}
      {output && <pre style={STYLE.out}>{output}</pre>}
    </div>
  )
}
