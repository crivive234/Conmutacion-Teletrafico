/**
 * StreamCard — one card per RTP stream (SSRC).
 * Shows: SSRC id, codec, MOS gauge, R-factor, jitter, loss, delay, band.
 */

const BAND_COLOR = {
  EXCELLENT:    'var(--green)',
  GOOD:         'var(--green)',
  ACCEPTABLE:   'var(--amber)',
  POOR:         'var(--red)',
  UNACCEPTABLE: 'var(--red)',
}

const STYLE = {
  card: {
    background: 'var(--bg-1)',
    border: '1px solid var(--border)',
    padding: 18,
    display: 'flex', flexDirection: 'column', gap: 14,
  },
  head: { display: 'flex', justifyContent: 'space-between',
          alignItems: 'baseline' },
  ssrc: { fontSize: 11, color: 'var(--fg-2)', letterSpacing: '0.1em' },
  codec: { fontSize: 10, color: 'var(--fg-3)', textTransform: 'uppercase' },
  band: {
    fontSize: 10, fontWeight: 600, padding: '3px 8px',
    border: '1px solid currentColor', letterSpacing: '0.12em',
  },
  mosRow: { display: 'flex', alignItems: 'flex-end', gap: 12 },
  mos: { fontSize: 56, fontWeight: 300, lineHeight: 1,
         fontVariantNumeric: 'tabular-nums' },
  mosLabel: { fontSize: 10, color: 'var(--fg-2)', letterSpacing: '0.12em',
              textTransform: 'uppercase', paddingBottom: 8 },
  metrics: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
             gap: 12, paddingTop: 8, borderTop: '1px solid var(--border)' },
  m: { display: 'flex', flexDirection: 'column', gap: 3 },
  mLabel: { fontSize: 9, color: 'var(--fg-2)', letterSpacing: '0.12em',
            textTransform: 'uppercase' },
  mVal: { fontSize: 16, fontWeight: 500, fontVariantNumeric: 'tabular-nums' },
  mUnit: { fontSize: 11, color: 'var(--fg-2)' },
  bar: {
    position: 'relative', height: 3, background: 'var(--bg-3)',
    overflow: 'hidden',
  },
  barFill: { position: 'absolute', top: 0, left: 0, height: '100%' },
}

function MOSBar({ mos }) {
  // 0 → 4.5 maps to 0–100 %
  const pct = Math.max(0, Math.min(100, (mos / 4.5) * 100))
  const color = mos >= 4.0 ? 'var(--green)'
              : mos >= 3.6 ? 'var(--green)'
              : mos >= 3.1 ? 'var(--amber)'
              :              'var(--red)'
  return (
    <div style={STYLE.bar}>
      <div style={{ ...STYLE.barFill, width: `${pct}%`, background: color,
                    transition: 'width 400ms ease, background 200ms' }} />
    </div>
  )
}

export default function StreamCard({ s }) {
  const color = BAND_COLOR[s.band] || 'var(--fg-2)'
  return (
    <div style={STYLE.card}>
      <div style={STYLE.head}>
        <div>
          <div style={STYLE.ssrc}>SSRC {s.ssrc_hex}</div>
          <div style={STYLE.codec}>{s.codec}</div>
        </div>
        <span style={{ ...STYLE.band, color }}>{s.band}</span>
      </div>

      <div style={STYLE.mosRow}>
        <span style={{ ...STYLE.mos, color }}>{s.mos.toFixed(2)}</span>
        <span style={STYLE.mosLabel}>MOS<br/>R = {s.r_factor}</span>
      </div>

      <MOSBar mos={s.mos} />

      <div style={STYLE.metrics}>
        <div style={STYLE.m}>
          <span style={STYLE.mLabel}>Jitter</span>
          <span style={STYLE.mVal}>
            {s.jitter_ms.toFixed(1)}<span style={STYLE.mUnit}> ms</span>
          </span>
        </div>
        <div style={STYLE.m}>
          <span style={STYLE.mLabel}>Loss</span>
          <span style={STYLE.mVal}>
            {(s.loss_rate * 100).toFixed(2)}<span style={STYLE.mUnit}> %</span>
          </span>
        </div>
        <div style={STYLE.m}>
          <span style={STYLE.mLabel}>Delay</span>
          <span style={STYLE.mVal}>
            {Math.round(s.one_way_delay_ms)}<span style={STYLE.mUnit}> ms</span>
          </span>
        </div>
      </div>
    </div>
  )
}
