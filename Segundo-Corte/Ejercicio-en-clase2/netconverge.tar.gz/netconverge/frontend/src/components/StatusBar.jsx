import { useEffect, useState } from 'react'

const STYLE = {
  bar: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '12px 20px', borderBottom: '1px solid var(--border)',
    background: 'var(--bg-1)',
  },
  brand: {
    display: 'flex', alignItems: 'center', gap: 14,
    fontWeight: 600, letterSpacing: '0.04em',
  },
  mark: {
    width: 22, height: 22, position: 'relative',
    border: '1px solid var(--amber)',
  },
  innerMark: {
    position: 'absolute', inset: 4, background: 'var(--amber)',
  },
  meta: { display: 'flex', alignItems: 'center', gap: 24, fontSize: 11 },
  metaItem: { color: 'var(--fg-2)', textTransform: 'uppercase',
              letterSpacing: '0.1em' },
  metaVal: { color: 'var(--fg-0)', marginLeft: 8 },
}

export default function StatusBar({ connected }) {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  const time = now.toISOString().substring(11, 19)  + ' UTC'
  return (
    <div style={STYLE.bar}>
      <div style={STYLE.brand}>
        <div style={STYLE.mark}><div style={STYLE.innerMark} /></div>
        <span>NETCONVERGE</span>
        <span style={{color: 'var(--fg-3)', fontWeight: 400}}>// console</span>
      </div>
      <div style={STYLE.meta}>
        <div style={STYLE.metaItem}>
          <span className="dot" style={{background:
            connected ? 'var(--green)' : 'var(--red)',
            boxShadow: connected ? '0 0 0 3px rgba(122,184,122,0.18)' : 'none'
          }} />
          <span style={STYLE.metaVal}>{connected ? 'LINKED' : 'OFFLINE'}</span>
        </div>
        <div style={STYLE.metaItem}>UPTIME<span style={STYLE.metaVal}>00:00:42</span></div>
        <div style={STYLE.metaItem}>{time}</div>
      </div>
    </div>
  )
}
