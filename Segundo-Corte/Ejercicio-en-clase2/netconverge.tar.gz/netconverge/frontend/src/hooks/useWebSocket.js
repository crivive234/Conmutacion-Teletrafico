import { useEffect, useRef, useState } from 'react'

/**
 * useWebSocket — subscribes to a JSON-message WebSocket with auto-reconnect.
 *
 * Returns:
 *   data       — last parsed message (null until first arrives)
 *   connected  — boolean live status
 *   history    — rolling array of last N messages (for spark charts)
 */
export default function useWebSocket(url, { historySize = 60 } = {}) {
  const [data, setData] = useState(null)
  const [connected, setConnected] = useState(false)
  const [history, setHistory] = useState([])
  const wsRef = useRef(null)

  useEffect(() => {
    let mounted = true
    let retryTimer = null

    const connect = () => {
      let ws
      try { ws = new WebSocket(url) } catch { 
        if (mounted) retryTimer = setTimeout(connect, 2000); return
      }
      wsRef.current = ws

      ws.onopen = () => {
        if (!mounted) return
        setConnected(true)
        try { ws.send('hello') } catch {}
      }
      ws.onclose = () => {
        if (!mounted) return
        setConnected(false)
        retryTimer = setTimeout(connect, 2000)
      }
      ws.onerror = () => { try { ws.close() } catch {} }
      ws.onmessage = (e) => {
        try {
          const parsed = JSON.parse(e.data)
          setData(parsed)
          setHistory(h => {
            const next = [...h, parsed]
            return next.length > historySize ? next.slice(-historySize) : next
          })
        } catch {}
      }
    }

    connect()
    return () => {
      mounted = false
      if (retryTimer) clearTimeout(retryTimer)
      try { wsRef.current?.close() } catch {}
    }
  }, [url, historySize])

  return { data, connected, history }
}
