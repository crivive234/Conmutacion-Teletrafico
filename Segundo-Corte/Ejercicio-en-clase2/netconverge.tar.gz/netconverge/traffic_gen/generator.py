"""
Standalone traffic generator container — emits synthetic RTP-stream metrics
to the backend over WebSocket. In a real deployment this would be replaced
with Scapy capturing the wire; in our simulation it's pure Python.

This container is optional: the backend already runs its own simulation
loop. This service exists to demonstrate the same pipeline runs as a
separate process.
"""
from __future__ import annotations
import asyncio
import json
import os
import time

from netconverge.application.analysis.rtp_quality import RTPStreamAnalyzer
from netconverge.infrastructure.capture.synthetic import synth_g711_stream


async def main() -> None:
    backend = os.environ.get("BACKEND_URL", "ws://backend:8000/ws/telemetry")
    print(f"[traffic-gen] target = {backend}", flush=True)

    profiles = [
        (0xDEAD0001, dict(loss_rate=0.001, jitter_ms=2.5),  60),
        (0xDEAD0002, dict(loss_rate=0.02,  jitter_ms=12.0), 80),
        (0xDEAD0003, dict(loss_rate=0.07,  jitter_ms=30.0), 200),
    ]

    while True:
        for ssrc, p, owd in profiles:
            a = RTPStreamAnalyzer(ssrc=ssrc, assumed_owd_ms=owd)
            for pkt in synth_g711_stream(packets=500, **p, seed=ssrc + int(time.time()) % 10):
                a.ingest(pkt)
            snap = a.snapshot()
            print(f"[traffic-gen] ssrc=0x{ssrc:X} mos={snap.mos} "
                  f"loss={snap.loss_rate*100:.2f}% jitter={snap.jitter_ms:.1f}ms",
                  flush=True)
        await asyncio.sleep(5)


if __name__ == "__main__":
    asyncio.run(main())
