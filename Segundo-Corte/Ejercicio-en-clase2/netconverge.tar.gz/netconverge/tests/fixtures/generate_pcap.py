"""
Generate a deterministic RTP .pcap file with no external deps.

Writes raw libpcap format (DLT_RAW = 101, raw IPv4 frames) using only
stdlib `struct`. Run once to (re)generate the fixture:

    python tests/fixtures/generate_pcap.py

The fixture contains a 200-packet G.711 stream with two intentional drops
so loss detection can be exercised by the integration tests.
"""
from __future__ import annotations
import struct
from pathlib import Path


PCAP_MAGIC = 0xA1B2C3D4    # big-endian when read big-endian
DLT_RAW = 101              # raw IPv4 (no link-layer)
SNAPLEN = 65535


def _ipv4_header(src: bytes, dst: bytes, total_len: int, proto: int = 17) -> bytes:
    ver_ihl = 0x45
    tos = 0
    ident = 0
    flags_frag = 0
    ttl = 64
    hdr = struct.pack("!BBHHHBBH4s4s",
                      ver_ihl, tos, total_len, ident, flags_frag,
                      ttl, proto, 0, src, dst)
    # one's complement checksum
    s = sum(struct.unpack("!10H", hdr))
    s = (s & 0xFFFF) + (s >> 16)
    s = (s & 0xFFFF) + (s >> 16)
    chksum = (~s) & 0xFFFF
    return hdr[:10] + struct.pack("!H", chksum) + hdr[12:]


def _udp_header(sport: int, dport: int, length: int) -> bytes:
    return struct.pack("!HHHH", sport, dport, length, 0)


def _rtp_header(seq: int, timestamp: int, ssrc: int, pt: int = 0) -> bytes:
    return struct.pack("!BBHII", 0x80, pt & 0x7F,
                       seq & 0xFFFF, timestamp & 0xFFFFFFFF, ssrc & 0xFFFFFFFF)


def _ip(addr: str) -> bytes:
    return bytes(int(o) for o in addr.split("."))


def main() -> None:
    out = Path(__file__).parent / "rtp_g711_sample.pcap"

    ssrc = 0xCAFEBEEF
    src_ip = _ip("10.0.0.10")
    dst_ip = _ip("10.0.0.20")
    sport, dport = 16400, 16402
    samples_per_pkt = 160
    payload_size = 160

    with out.open("wb") as f:
        # pcap global header (big-endian)
        f.write(struct.pack(">IHHIIII", PCAP_MAGIC, 2, 4, 0, 0, SNAPLEN, DLT_RAW))

        seq = 1000
        ts = 0
        written = 0
        for i in range(200):
            seq = (seq + 1) & 0xFFFF
            ts += samples_per_pkt
            if i in (50, 150):
                continue   # simulate dropped packets

            rtp = _rtp_header(seq, ts, ssrc) + bytes(payload_size)
            udp_len = 8 + len(rtp)
            packet = (_ipv4_header(src_ip, dst_ip, 20 + udp_len) +
                      _udp_header(sport, dport, udp_len) + rtp)

            cap_us = i * 20_000   # 20 ms inter-arrival
            ts_sec, ts_usec = divmod(cap_us, 1_000_000)
            f.write(struct.pack(">IIII", ts_sec, ts_usec, len(packet), len(packet)))
            f.write(packet)
            written += 1

    print(f"wrote {written} packets → {out}")


if __name__ == "__main__":
    main()
