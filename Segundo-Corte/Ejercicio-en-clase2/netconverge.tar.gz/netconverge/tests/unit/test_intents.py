"""Validation rules in domain.models.intents."""
import pytest
from pydantic import ValidationError

from netconverge.domain.models.intents import (
    VoiceAccessPort, QoSPolicy, QoSClass, ACL, ACLRule, DSCP,
)


class TestVoiceAccessPort:
    def test_valid(self):
        p = VoiceAccessPort(interface="Gi0/1", data_vlan=10, voice_vlan=20)
        assert p.data_vlan == 10
        assert p.voice_vlan == 20

    def test_voice_must_differ_from_data(self):
        with pytest.raises(ValidationError, match="differ"):
            VoiceAccessPort(interface="Gi0/1", data_vlan=10, voice_vlan=10)

    def test_vlan_range_enforced(self):
        with pytest.raises(ValidationError):
            VoiceAccessPort(interface="Gi0/1", data_vlan=0, voice_vlan=20)
        with pytest.raises(ValidationError):
            VoiceAccessPort(interface="Gi0/1", data_vlan=10, voice_vlan=4095)


class TestQoSPolicy:
    def test_valid(self):
        p = QoSPolicy(name="WAN", apply_to_interface="Gi0/0", classes=[
            QoSClass(name="VOICE", match_dscp=DSCP.EF, priority=True, bandwidth_percent=30),
        ])
        assert p.classes[0].match_dscp == "ef"   # use_enum_values

    def test_bandwidth_budget_capped(self):
        with pytest.raises(ValidationError, match="exceeds 99"):
            QoSPolicy(name="WAN", apply_to_interface="Gi0/0", classes=[
                QoSClass(name="A", match_dscp=DSCP.EF,   bandwidth_percent=50),
                QoSClass(name="B", match_dscp=DSCP.AF41, bandwidth_percent=50),
            ])


class TestACL:
    def test_valid_rule(self):
        r = ACLRule(action="permit", protocol="udp", dst_port=5060)
        assert r.dst_port == 5060

    def test_port_range_must_be_ordered(self):
        with pytest.raises(ValidationError, match="low < high"):
            ACLRule(action="permit", protocol="udp", dst_port_range=(8000, 5000))

    def test_full_acl(self):
        acl = ACL(name="V", rules=[
            ACLRule(action="permit", protocol="udp", dst_port=5060),
            ACLRule(action="deny", protocol="ip"),
        ])
        assert len(acl.rules) == 2
