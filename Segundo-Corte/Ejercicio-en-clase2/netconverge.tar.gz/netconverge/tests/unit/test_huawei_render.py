"""Huawei VRP template rendering — verify exact command strings."""
from netconverge.domain.models.intents import (
    VoiceAccessPort, QoSPolicy, QoSClass, ACL, ACLRule, DSCP,
)
from netconverge.infrastructure.vendors.huawei_vrp import HuaweiVRP


def test_voice_port_emits_huawei_canonical_commands():
    cfg = HuaweiVRP().render_voice_port(VoiceAccessPort(
        interface="GigabitEthernet0/0/1",
        description="Phone+PC",
        data_vlan=10,
        voice_vlan=20,
    ))
    assert "interface GigabitEthernet0/0/1" in cfg
    assert " port link-type access" in cfg
    assert " port default vlan 10" in cfg
    assert " voice-vlan 20 enable" in cfg
    assert " voice-vlan mode auto" in cfg
    assert " trust 8021p" in cfg
    assert " stp edged-port enable" in cfg
    assert " bpdu-protection enable" in cfg
    assert " undo shutdown" in cfg
    # huawei block separator
    assert cfg.rstrip().endswith("#")


def test_qos_policy_uses_traffic_classifier_behavior_policy_chain():
    pol = QoSPolicy(name="WAN-EGRESS", apply_to_interface="Gi0/0/1", classes=[
        QoSClass(name="VOICE-RTP", match_dscp=DSCP.EF, priority=True, bandwidth_percent=30),
        QoSClass(name="VIDEO-RTP", match_dscp=DSCP.AF41, bandwidth_percent=30),
    ])
    cfg = HuaweiVRP().render_qos_policy(pol)
    # classifier section uses NUMERIC dscp on Huawei
    assert "traffic classifier VOICE-RTP operator or" in cfg
    assert " if-match dscp 46" in cfg
    assert " if-match dscp 34" in cfg
    # behaviors
    assert "traffic behavior VOICE-RTP-b" in cfg
    assert " queue ef bandwidth pct 30" in cfg
    assert "traffic behavior VIDEO-RTP-b" in cfg
    assert " queue af bandwidth pct 30" in cfg
    # default behavior
    assert "traffic behavior default-b" in cfg
    assert " queue wfq" in cfg
    # policy + binding
    assert "traffic policy WAN-EGRESS" in cfg
    assert " classifier VOICE-RTP behavior VOICE-RTP-b" in cfg
    # apply outbound
    assert "interface Gi0/0/1" in cfg
    assert " traffic-policy WAN-EGRESS outbound" in cfg


def test_acl_advanced_uses_3000_range_and_rule_increment():
    acl = ACL(name="VOICE-PERMIT", type="extended", rules=[
        ACLRule(action="permit", protocol="udp", dst_port=5060, remark="SIP"),
        ACLRule(action="permit", protocol="udp",
                dst_port_range=(16384, 32767), remark="RTP"),
        ACLRule(action="deny", protocol="ip"),
    ])
    cfg = HuaweiVRP().render_acl(acl)
    # advanced ACL → 3000-range
    assert "acl name VOICE-PERMIT advance number 3000" in cfg
    # rule numbering increments by 5
    assert " rule 5 permit udp destination-port eq 5060" in cfg
    assert " rule 10 permit udp destination-port range 16384 32767" in cfg
    assert " rule 15 deny ip" in cfg
    # description preserved
    assert " rule 5 description SIP" in cfg


def test_acl_basic_uses_2000_range():
    acl = ACL(name="MGMT-LIMIT", type="standard", rules=[
        ACLRule(action="deny", protocol="ip"),
    ])
    cfg = HuaweiVRP().render_acl(acl)
    assert "acl name MGMT-LIMIT basic number 2000" in cfg
