"""Cisco IOS template rendering — verify exact command strings."""
from netconverge.domain.models.intents import (
    VoiceAccessPort, QoSPolicy, QoSClass, ACL, ACLRule, DSCP,
)
from netconverge.infrastructure.vendors.cisco_ios import CiscoIOS


def _strip(s: str) -> list[str]:
    return [ln.rstrip() for ln in s.splitlines() if ln.strip()]


def test_voice_port_emits_canonical_commands():
    cfg = CiscoIOS().render_voice_port(VoiceAccessPort(
        interface="GigabitEthernet0/1",
        description="Phone+PC",
        data_vlan=10,
        voice_vlan=20,
    ))
    lines = _strip(cfg)
    assert "interface GigabitEthernet0/1" in lines
    assert " switchport mode access" in lines
    assert " switchport access vlan 10" in lines
    assert " switchport voice vlan 20" in lines
    assert " mls qos trust cos" in lines
    assert " spanning-tree portfast" in lines
    assert " spanning-tree bpduguard enable" in lines
    assert " no shutdown" in lines
    # description appears as written
    assert " description Phone+PC" in lines


def test_voice_port_dscp_trust_alternative():
    cfg = CiscoIOS().render_voice_port(VoiceAccessPort(
        interface="Gi0/1", data_vlan=10, voice_vlan=20, trust_mode="dscp",
    ))
    assert " mls qos trust dscp" in cfg
    assert " mls qos trust cos" not in cfg


def test_qos_policy_priority_class_emits_priority_percent():
    pol = QoSPolicy(name="WAN", apply_to_interface="Gi0/0", classes=[
        QoSClass(name="VOICE-RTP", match_dscp=DSCP.EF, priority=True, bandwidth_percent=30),
        QoSClass(name="VIDEO-RTP", match_dscp=DSCP.AF41, bandwidth_percent=30),
    ])
    cfg = CiscoIOS().render_qos_policy(pol)
    assert "class-map match-any VOICE-RTP" in cfg
    assert " match ip dscp ef" in cfg          # symbolic Cisco form
    assert " match ip dscp af41" in cfg
    assert "policy-map WAN" in cfg
    assert "  priority percent 30" in cfg
    assert "  bandwidth percent 30" in cfg
    # default class housekeeping
    assert " class class-default" in cfg
    assert "  fair-queue" in cfg
    # service-policy attachment
    assert " service-policy output WAN" in cfg


def test_acl_extended_with_remarks_and_port_range():
    acl = ACL(name="VOICE-PERMIT", type="extended", rules=[
        ACLRule(action="permit", protocol="udp", dst_port=5060, remark="SIP"),
        ACLRule(action="permit", protocol="udp",
                dst_port_range=(16384, 32767), remark="RTP"),
        ACLRule(action="deny", protocol="ip"),
    ])
    cfg = CiscoIOS().render_acl(acl)
    assert "ip access-list extended VOICE-PERMIT" in cfg
    assert " remark SIP" in cfg
    assert " permit udp any any eq 5060" in cfg
    assert " remark RTP" in cfg
    assert " permit udp any any range 16384 32767" in cfg
    assert " deny ip any any" in cfg
    # idempotency — leading "no ip access-list ..." clears existing
    assert cfg.startswith("no ip access-list extended VOICE-PERMIT")
