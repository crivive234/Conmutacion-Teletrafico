"""
RTP quality metrics tests.

Includes:
  - RFC 3550 §6.4.1 jitter calculation
  - 16-bit sequence-number wrap-around handling
  - ITU-T G.107 reference points (verified by manual calibration)
"""
from __future__ import annotations
import pytest

from netconverge.application.analysis.rtp_quality import (
    RTPStreamAnalyzer, RTPPacket, CODEC_PARAMS,
)
from netconverge.domain.models.telemetry import quality_band


# ============================================================ packet ingestion
class TestPacketIngestion:
    def test_no_loss_when_sequence_increments(self):
        a = RTPStreamAnalyzer(ssrc=1)
        for i in range(10):
            a.ingest(RTPPacket(seq=100 + i, timestamp=i * 160,
                               arrival_s=i * 0.020, payload_type=0))
        assert a.m.packets_received == 10
        assert a.m.packets_lost == 0
        assert a.m.packets_expected == 10

    def test_loss_detected_from_seq_gap(self):
        a = RTPStreamAnalyzer(ssrc=1)
        for s in [100, 101, 102, 105, 106]:   # 103, 104 missing
            a.ingest(RTPPacket(seq=s, timestamp=s * 160,
                               arrival_s=s * 0.020, payload_type=0))
        assert a.m.packets_received == 5
        assert a.m.packets_lost == 2

    def test_duplicate_seq_does_not_count_as_loss(self):
        a = RTPStreamAnalyzer(ssrc=1)
        a.ingest(RTPPacket(seq=100, timestamp=0, arrival_s=0.0, payload_type=0))
        a.ingest(RTPPacket(seq=100, timestamp=0, arrival_s=0.020, payload_type=0))
        assert a.m.packets_lost == 0

    def test_out_of_order_does_not_count_as_loss(self):
        a = RTPStreamAnalyzer(ssrc=1)
        a.ingest(RTPPacket(seq=100, timestamp=0,   arrival_s=0.0,   payload_type=0))
        a.ingest(RTPPacket(seq=102, timestamp=320, arrival_s=0.040, payload_type=0))
        a.ingest(RTPPacket(seq=101, timestamp=160, arrival_s=0.060, payload_type=0))  # late
        # seq 100,102 → 1 lost (the 101 we just got isn't recounted as new gap)
        assert a.m.packets_lost == 1

    def test_seq_wraparound(self):
        a = RTPStreamAnalyzer(ssrc=1)
        for s in [65534, 65535, 0, 1]:  # rollover at the 16-bit boundary
            a.ingest(RTPPacket(seq=s & 0xFFFF, timestamp=s * 160,
                               arrival_s=s * 0.020, payload_type=0))
        assert a.m.packets_lost == 0
        assert a.m.packets_received == 4


# ============================================================ jitter (RFC 3550)
class TestJitter:
    def test_zero_jitter_for_perfect_arrival(self):
        a = RTPStreamAnalyzer(ssrc=1)
        for i in range(100):
            # Each packet exactly 20 ms apart with timestamp incrementing 160 samples
            a.ingest(RTPPacket(seq=i, timestamp=i * 160,
                               arrival_s=i * 0.020, payload_type=0))
        # With perfectly-paced arrivals, jitter must be ≈ 0
        assert a.m.jitter_ms == pytest.approx(0.0, abs=0.01)

    def test_jitter_grows_with_arrival_variance(self):
        import random
        rng = random.Random(7)
        a = RTPStreamAnalyzer(ssrc=1)
        for i in range(500):
            wobble = rng.gauss(0, 0.005)   # 5 ms σ
            a.ingest(RTPPacket(seq=i, timestamp=i * 160,
                               arrival_s=i * 0.020 + wobble,
                               payload_type=0))
        assert a.m.jitter_ms > 1.0      # real jitter should appear
        assert a.m.jitter_ms < 20.0     # but bounded


# ============================================================ E-model (G.107)
class TestEModel:
    def _quality(self, *, owd_ms: float, loss_rate: float,
                 jitter_ms: float = 0.0, payload_type: int = 0):
        a = RTPStreamAnalyzer(ssrc=1, assumed_owd_ms=owd_ms)
        a.m.packets_received = 1000
        a.m.packets_expected = 1000
        a.m.packets_lost = int(1000 * loss_rate)
        a.m.jitter_ms = jitter_ms
        return a.compute_quality(payload_type=payload_type)

    def test_perfect_g711_low_delay_is_excellent(self):
        r = self._quality(owd_ms=50, loss_rate=0.0)
        # Calibrated reference: G.711, 50ms one-way → R≈92, MOS≈4.38
        assert r.r_factor == pytest.approx(92.0, abs=1.0)
        assert r.mos == pytest.approx(4.38, abs=0.05)
        assert quality_band(r.mos) == "EXCELLENT"

    def test_g711_at_150ms_still_excellent(self):
        # G.114 considers ≤150ms one-way "good for most applications"
        r = self._quality(owd_ms=150, loss_rate=0.0)
        assert r.r_factor == pytest.approx(89.6, abs=1.0)
        assert quality_band(r.mos) in ("EXCELLENT", "GOOD")

    def test_g711_above_177ms_uses_step_function(self):
        # The Heaviside step at 177.3 ms must add penalty for higher delays
        r_low = self._quality(owd_ms=177, loss_rate=0.0)
        r_high = self._quality(owd_ms=200, loss_rate=0.0)
        # 23 ms delta but penalty is greater than just 0.024×23 because step kicks in
        delta_extra = (r_low.r_factor - r_high.r_factor)
        assert delta_extra > 0.024 * 23      # confirm step applied

    def test_g711_5pct_loss_drops_to_good(self):
        r = self._quality(owd_ms=100, loss_rate=0.05)
        assert r.r_factor == pytest.approx(75.0, abs=2.0)
        assert quality_band(r.mos) == "GOOD"

    def test_g711_20pct_loss_unacceptable(self):
        r = self._quality(owd_ms=100, loss_rate=0.20)
        assert r.mos < 3.1
        assert quality_band(r.mos) in ("POOR", "UNACCEPTABLE")

    def test_g729_more_sensitive_to_loss_than_g711(self):
        r711 = self._quality(owd_ms=100, loss_rate=0.05, payload_type=0)
        r729 = self._quality(owd_ms=100, loss_rate=0.05, payload_type=18)
        # G.729 has higher Ie_base and lower Bpl → worse MOS at same loss
        assert r729.mos < r711.mos

    def test_mos_clamped_to_valid_range(self):
        # Construct an extreme bad case manually
        a = RTPStreamAnalyzer(ssrc=1, assumed_owd_ms=2000)
        a.m.packets_received = 1000
        a.m.packets_expected = 1000
        a.m.packets_lost = 500
        r = a.compute_quality(payload_type=0)
        assert 1.0 <= r.mos <= 4.5
        assert 0.0 <= r.r_factor <= 100.0


# ============================================================ codec params sanity
def test_codec_table_is_self_consistent():
    # All entries should have non-negative Ie and positive Bpl
    for pt, (name, Ie, Bpl) in CODEC_PARAMS.items():
        assert Ie >= 0
        assert Bpl > 0
        assert isinstance(name, str)
