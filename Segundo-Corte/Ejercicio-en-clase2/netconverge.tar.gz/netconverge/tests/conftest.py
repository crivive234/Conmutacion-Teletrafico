"""
Shared pytest fixtures.

Includes a fixture that builds a small synthetic RTP "pcap" — actually a
list of RTPPacket objects, since requiring libpcap in CI is overkill. The
real Scapy capture path is exercised in tests/integration/ when scapy is
available.
"""
from __future__ import annotations
import pytest

from netconverge.application.analysis.rtp_quality import RTPPacket
from netconverge.infrastructure.capture.synthetic import synth_g711_stream


@pytest.fixture
def healthy_stream() -> list[RTPPacket]:
    """1000 G.711 packets, ~0% loss, low jitter — should yield MOS ≥ 4.0."""
    return list(synth_g711_stream(
        packets=1000, loss_rate=0.0, jitter_ms=1.0, seed=1,
    ))


@pytest.fixture
def degraded_stream() -> list[RTPPacket]:
    """1000 G.711 packets with 5% loss and 15 ms jitter."""
    return list(synth_g711_stream(
        packets=1000, loss_rate=0.05, jitter_ms=15.0, seed=2,
    ))


@pytest.fixture
def bad_stream() -> list[RTPPacket]:
    """1000 G.711 packets with 12% loss and 30 ms jitter."""
    return list(synth_g711_stream(
        packets=1000, loss_rate=0.12, jitter_ms=30.0, seed=3,
    ))
