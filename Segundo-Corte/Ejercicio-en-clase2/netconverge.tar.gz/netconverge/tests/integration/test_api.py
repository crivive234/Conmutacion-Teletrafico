"""HTTP API tests using FastAPI's TestClient."""
from fastapi.testclient import TestClient
import pytest


@pytest.fixture(scope="module")
def client():
    # Import lazily so the lifespan doesn't kick off the bg loop on every test
    from netconverge.infrastructure.transport.api import app
    with TestClient(app) as c:
        yield c


def test_health(client):
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_vendors_listed(client):
    r = client.get("/api/v1/vendors")
    assert r.status_code == 200
    vs = r.json()["vendors"]
    assert "cisco_ios" in vs
    assert "huawei_vrp" in vs


def test_render_voice_port_cisco(client):
    r = client.post("/api/v1/config/render", json={
        "vendor": "cisco_ios",
        "intent_type": "voice_port",
        "intent_data": {
            "interface": "GigabitEthernet0/1",
            "data_vlan": 10, "voice_vlan": 20,
            "description": "test",
        },
    })
    assert r.status_code == 200
    assert "switchport voice vlan 20" in r.json()["config"]


def test_render_acl_huawei(client):
    r = client.post("/api/v1/config/render", json={
        "vendor": "huawei_vrp",
        "intent_type": "acl",
        "intent_data": {
            "name": "T",
            "type": "extended",
            "rules": [
                {"action": "permit", "protocol": "udp", "dst_port": 5060},
                {"action": "deny", "protocol": "ip"},
            ],
        },
    })
    assert r.status_code == 200
    assert "acl name T advance number 3000" in r.json()["config"]


def test_unknown_vendor_returns_404(client):
    r = client.post("/api/v1/config/render", json={
        "vendor": "junos",
        "intent_type": "voice_port",
        "intent_data": {"interface": "ge-0/0/0", "data_vlan": 10, "voice_vlan": 20},
    })
    assert r.status_code == 404


def test_invalid_intent_returns_422(client):
    r = client.post("/api/v1/config/render", json={
        "vendor": "cisco_ios",
        "intent_type": "voice_port",
        "intent_data": {"interface": "Gi0/1", "data_vlan": 10, "voice_vlan": 10},
    })
    assert r.status_code == 422
