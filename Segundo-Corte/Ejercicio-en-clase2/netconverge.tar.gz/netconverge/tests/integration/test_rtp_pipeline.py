"""
End-to-end integration test: read the pcap fixture, parse RTP packets,
feed the analyzer, verify metrics against the known-good fixture
characteristics.

The fixture has 198 packets out of 200 (2 dropped), G.711, 20 ms ptime.
"""
from __future__ import annotations
import struct
from pathlib import Path

import pytest

from netconverge.application.analysis.rtp_quality import (
    RTPPacket, RTPStreamAnalyzer,
)

FIXTURE = Path(__file__).parent.parent / "fixtures" / "rtp_g711_sample.pcap"


def _read_pcap_rtp(path: Path) -> list[RTPPacket]:
    """Minimal pcap → RTP parser (DLT_RAW, big-endian magic)."""
    pkts: list[RTPPacket] = []
    with path.open("rb") as f:
        global_hdr = f.read(24)
        magic = struct.unpack(">I", global_hdr[:4])[0]
        big_endian = magic == 0xA1B2C3D4
        endian = ">" if big_endian else "<"
        while True:
            rec = f.read(16)
            if len(rec) < 16:
                break
            ts_sec, ts_usec, incl_len, _orig = struct.unpack(endian + "IIII", rec)
            data = f.read(incl_len)
            # IPv4 header (assume IHL=5)
            ihl = (data[0] & 0x0F) * 4
            proto = data[9]
            if proto != 17:
                continue
            udp = data[ihl:ihl + 8]
            sport, dport, ulen, _csum = struct.unpack("!HHHH", udp)
            payload = data[ihl + 8:ihl + ulen]
            if len(payload) < 12:
                continue
            # RTP header
            seq = struct.unpack("!H", payload[2:4])[0]
            ts_rtp = struct.unpack("!I", payload[4:8])[0]
            pt = payload[1] & 0x7F
            arrival = ts_sec + ts_usec / 1_000_000
            pkts.append(RTPPacket(seq=seq, timestamp=ts_rtp, arrival_s=arrival,
                                  payload_type=pt))
    return pkts


@pytest.fixture(scope="module")
def parsed_pkts():
    if not FIXTURE.exists():
        pytest.skip(f"fixture not found: {FIXTURE}; run tests/fixtures/generate_pcap.py")
    return _read_pcap_rtp(FIXTURE)


def test_pcap_yields_expected_packet_count(parsed_pkts):
    # Fixture is 200 packets minus 2 dropped → 198
    assert len(parsed_pkts) == 198


def test_analyzer_detects_two_lost_packets(parsed_pkts):
    a = RTPStreamAnalyzer(ssrc=0xCAFEBEEF, assumed_owd_ms=50)
    for p in parsed_pkts:
        a.ingest(p)
    snap = a.snapshot(payload_type=0)
    assert snap.packets_received == 198
    assert snap.packets_lost == 2
    # ~1% loss
    assert snap.loss_rate == pytest.approx(2 / 199, abs=0.005)


def test_analyzer_reports_low_jitter_on_steady_stream(parsed_pkts):
    a = RTPStreamAnalyzer(ssrc=0xCAFEBEEF, assumed_owd_ms=50)
    for p in parsed_pkts:
        a.ingest(p)
    # The fixture has perfectly spaced 20 ms gaps → jitter should be near 0
    assert a.m.jitter_ms < 1.0


def test_analyzer_reports_excellent_quality(parsed_pkts):
    a = RTPStreamAnalyzer(ssrc=0xCAFEBEEF, assumed_owd_ms=50)
    for p in parsed_pkts:
        a.ingest(p)
    snap = a.snapshot(payload_type=0)
    # ~1% loss, low delay, no jitter → MOS should land in EXCELLENT or GOOD
    assert snap.mos >= 3.6
